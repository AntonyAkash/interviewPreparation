import React from 'react'

function Child() {
  //js
  return (//html js + html=jsx Es7
    <div>
      <h1> vine Hello, World!</h1>
    </div>
  )
}

export default Child