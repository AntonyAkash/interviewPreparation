import './App.css';
import Child from './components/Child';
import Classcomponent from './components/Classcomponent';
import Parent from './components/Parent';


function App() {
  return (
    <div className="App-header">
     <Parent/> 
    </div>
  );
}

export default App;
